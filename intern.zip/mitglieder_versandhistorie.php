<?php
define('APP_ENTRY_POINT', true);
require __DIR__ . '/app/Modules/Mitgliederverwaltung/Pages/history.php';
