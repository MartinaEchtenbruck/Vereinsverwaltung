<?php
if (!defined('APP_ENTRY_POINT')) { http_response_code(404); exit; }
$salesPage='overview';
require __DIR__.'/_controller.php';
require __DIR__.'/_layout_start.php';
?>
<section class="card action-header"><a href="verkauf.php?aktion=<?=$selected?>" class="back-link"><i class="fas fa-arrow-left"></i> Zurück zur Aktionsbearbeitung</a><div class="action-title-row"><div><h2><?=sh($action['title'])?> <span class="tag <?=sh($action['status'])?>"><?=['draft'=>'Entwurf','active'=>'Aktiv','closed'=>'Bestellschluss erreicht','completed'=>'Abgeschlossen'][$action['status']]?></span></h2><p class="action-period">Zeitraum: <?=date('d.m.Y',strtotime($action['start_date']))?> – <?=date('d.m.Y',strtotime($action['end_date']))?></p><p class="action-description"><?=nl2br(sh($action['description']??''))?></p></div></div><p>Öffentliche Bestellseite: <a href="../bestellen/" target="_blank" rel="noopener">/bestellen/</a></p>
<?php if(in_array($action['status'],['active','closed'],true)): ?><form method="post" onsubmit="return confirm('Aktion abschließen? Danach sind die Werte eingefroren.');"><input type="hidden" name="csrf_token" value="<?=sh($csrf)?>"><input type="hidden" name="do" value="complete_action"><input type="hidden" name="action_id" value="<?=$selected?>"><button class="btn btn-success btnwide">Aktion abschließen und Werte einfrieren</button></form><?php endif; ?></section>
<section class="card"><h2>Finanzübersicht</h2><div class="stats"><div class="stat">Erwarteter Verkaufserlös<strong><?=salesMoney($stats['revenue'])?></strong></div><div class="stat">Zahlungseingänge<br>(bezahlt markiert)<strong><?=salesMoney($stats['paid'])?></strong></div><div class="stat">Einkaufskosten<strong><?=salesMoney($stats['purchase'])?></strong></div><div class="stat">Gesamtkosten<strong><?=salesMoney($stats['purchase'])?></strong></div><div class="stat">Voraussichtlicher Überschuss<strong><?=salesMoney($stats['revenue']-$stats['purchase'])?></strong></div></div><?php if($variantBreakdowns): ?><p class="muted">Artikel mit Ausprägungen lassen sich aufklappen. Die Aufschlüsselung zeigt die Elternbestellungen je Eigenschaftskombination; interne Mengen werden nur auf Artikelebene erfasst.</p><?php endif; ?><div class="tablewrap"><table class="finance-table"><thead><tr><th>Artikel</th><th>Elternmenge</th><th>Interne Menge</th><th>Gesamt zu bestellen</th><th>Einkaufspreis</th><th>Gesamtkosten</th></tr></thead><tbody><?php foreach($items as $it): $pq=0;foreach($orders as $o){$q=$conn->prepare('SELECT COALESCE(SUM(quantity),0) FROM sales_order_items WHERE order_id=? AND item_id=?');$q->execute([$o['id'],$it['id']]);$pq+=(int)$q->fetchColumn();}$iq=$internal[$it['id']]??0;$totalQty=$pq+$iq;$iid=(int)$it['id'];$hasVariants=!empty($variantBreakdowns[$iid]); ?><tr class="finance-item-row<?=$hasVariants?' has-variants':''?>" <?php if($hasVariants): ?>data-variant-toggle-row data-target="variant-rows-<?=$iid?>" tabindex="0" role="button" aria-expanded="false" aria-label="Details zu <?=sh($it['name'])?> anzeigen" onclick="toggleVariantRows('variant-rows-<?=$iid?>')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();toggleVariantRows('variant-rows-<?=$iid?>')}"<?php endif; ?>><td><span class="finance-item-name"><?=sh($it['name'])?></span></td><td><?=$pq?></td><td><?=$iq?></td><td><strong><?=$totalQty?></strong></td><td><?=salesMoney((int)$it['purchase_price_cents'])?></td><td><?=salesMoney($totalQty*(int)$it['purchase_price_cents'])?><?php if($hasVariants): ?> <button type="button" class="variant-toggle-icon" aria-expanded="false" aria-controls="variant-rows-<?=$iid?>" data-target="variant-rows-<?=$iid?>" title="Eigenschaften anzeigen" aria-label="Eigenschaften von <?=sh($it['name'])?> anzeigen" onclick="event.stopPropagation();toggleVariantRows('variant-rows-<?=$iid?>')"><i class="fas fa-search" aria-hidden="true"></i></button><?php endif; ?></td></tr><?php if($hasVariants): foreach($variantBreakdowns[$iid] as $variant): $variantQty=(int)$variant['quantity']; ?><tr class="variant-detail-row" data-parent="variant-rows-<?=$iid?>" hidden><td><span class="variant-detail-label">↳ <?=sh($variant['label'])?></span></td><td><?=$variantQty?></td><td>–</td><td><?=$variantQty?></td><td><?=salesMoney((int)$it['purchase_price_cents'])?></td><td><?=salesMoney($variantQty*(int)$it['purchase_price_cents'])?></td></tr><?php endforeach; endif; ?><?php endforeach; ?></tbody></table></div></section>
<section class="card"><h2>Interne Bestellung (Kindergarten)</h2><p>Hier die zusätzlichen Mengen für den Kindergarten eintragen. Alle Artikel stehen zur Verfügung, auch solche, die nicht an Eltern verkauft werden.</p><form method="post"><input type="hidden" name="csrf_token" value="<?=sh($csrf)?>"><input type="hidden" name="do" value="save_internal"><input type="hidden" name="action_id" value="<?=$selected?>"><div class="tablewrap"><table><thead><tr><th>Artikel</th><th>Einkaufspreis</th><th>Interne Menge</th></tr></thead><tbody><?php foreach($items as $it): ?><tr><td><?=sh($it['name'])?></td><td><?=salesMoney((int)$it['purchase_price_cents'])?></td><td><input type="number" name="internal_qty[<?=$it['id']?>]" min="0" max="100000" value="<?=$internal[$it['id']]??0?>" <?=$action['status']==='completed'?'disabled':''?>></td></tr><?php endforeach; ?></tbody></table></div><?php if($action['status']!=='completed'): ?><button class="btn btn-primary btnwide">Interne Bestellung speichern</button><?php endif; ?></form></section>
<section class="card"><h2>Elternbestellungen (<?=count($orders)?>)</h2><div class="filters"><input id="orderSearch" placeholder="Name oder E-Mail suchen"><select id="groupFilter"><option value="">Alle Gruppen</option><?php foreach($groups as $g): ?><option value="<?=sh($g['name'])?>"><?=sh($g['name'])?></option><?php endforeach; ?></select><select id="statusFilter"><option value="">Alle Bestellungen</option><option value="unpaid">Nicht bezahlt</option><option value="unpacked">Nicht gepackt</option><option value="unissued">Nicht ausgegeben</option></select></div><div class="tablewrap"><table id="ordersTable"><thead><tr><th>Bestellnr.</th><th>Name / E-Mail</th><th>Gruppe</th><?php foreach($items as $it): ?><th><?=sh($it['name'])?></th><?php endforeach; ?><th>Gesamt</th><th>Bezahlt</th><th>Gepackt</th><th>Ausgegeben</th><th></th></tr></thead><tbody><?php foreach($orders as $o): $q=$conn->prepare('SELECT group_name FROM sales_groups WHERE id=?');$q->execute([$o['group_id']]);$gname=(string)$q->fetchColumn();$oi=$conn->prepare('SELECT item_id,quantity,variant_text FROM sales_order_items WHERE order_id=?');$oi->execute([$o['id']]);$qtymap=[];$variantmap=[];foreach($oi->fetchAll(PDO::FETCH_ASSOC) as $r){$qtymap[(int)$r['item_id']]=(int)$r['quantity'];if(!empty($r['variant_text']))$variantmap[(int)$r['item_id']][]=$r['variant_text'];} ?><tr data-name="<?=sh(mb_strtolower($o['customer_name'].' '.$o['customer_email']))?>" data-group="<?=sh($gname)?>" data-paid="<?=$o['is_paid']?'1':'0'?>" data-packed="<?=$o['is_packed']?'1':'0'?>" data-issued="<?=$o['is_issued']?'1':'0'?>"><td><?=sh($o['order_number'])?><br><small><?=date('d.m.Y H:i',strtotime($o['created_at']))?></small></td><td><strong><?=sh($o['customer_name'])?></strong><br><a href="mailto:<?=sh($o['customer_email'])?>"><?=sh($o['customer_email'])?></a></td><td><?=sh($gname)?></td><?php foreach($items as $it): ?><td><?=$qtymap[$it['id']]??0?><?php if(!empty($variantmap[$it['id']])): ?><br><small><?=sh(implode('; ',$variantmap[$it['id']]))?></small><?php endif; ?></td><?php endforeach; ?><td><?=salesMoney((int)$o['total_cents'])?></td><?php foreach(['is_paid'=>'Bezahlt','is_packed'=>'Gepackt','is_issued'=>'Ausgegeben'] as $field=>$label): ?><td><form method="post"><input type="hidden" name="csrf_token" value="<?=sh($csrf)?>"><input type="hidden" name="do" value="order_status"><input type="hidden" name="action_id" value="<?=$selected?>"><input type="hidden" name="order_id" value="<?=$o['id']?>"><input type="hidden" name="field" value="<?=$field?>"><input type="checkbox" name="value" value="1" <?=$o[$field]?'checked':''?> onchange="this.form.submit()" aria-label="<?=$label?> für <?=sh($o['customer_name'])?>"></form></td><?php endforeach; ?><td><form method="post" onsubmit="return confirm('Bestellung endgültig löschen? Sie wird vollständig aus allen Berechnungen entfernt.');"><input type="hidden" name="csrf_token" value="<?=sh($csrf)?>"><input type="hidden" name="do" value="delete_order"><input type="hidden" name="action_id" value="<?=$selected?>"><input type="hidden" name="order_id" value="<?=$o['id']?>"><button class="smallbtn" title="Bestellung löschen"><i class="fas fa-trash"></i></button></form></td></tr><?php endforeach; ?></tbody></table></div></section>
<style>
.finance-table tr.finance-item-row.has-variants{cursor:pointer}
.finance-table tr.finance-item-row.has-variants:hover{background:#f4f7f9}
.finance-table tr.finance-item-row.has-variants:focus-visible{outline:2px solid var(--primary,#3977a8);outline-offset:-2px}
.finance-table .finance-item-name{font:inherit;font-weight:600;color:inherit}
.finance-table .variant-toggle-icon{display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;margin-left:8px;padding:0;border:1px solid #d6dde2;border-radius:6px;background:#fff;color:#52616b;cursor:pointer;vertical-align:middle}
.finance-table .variant-toggle-icon:hover{background:#edf3f6;color:#243746}
.finance-table .variant-toggle-icon[aria-expanded="true"]{background:#e8f0f5;color:#243746}
.finance-table .variant-detail-row{background:#f7f9fa;color:#56616b}
.finance-table .variant-detail-row[hidden]{display:none!important}
.finance-table .variant-detail-label{display:inline-block;padding-left:24px;font-size:.94em}
.finance-table .variant-detail-row td{border-top:1px solid #edf0f2}
</style>
<script>
function toggleVariantRows(target) {
    var detailRows = document.querySelectorAll('.finance-table tr.variant-detail-row');
    var matchingRows = [];
    for (var i = 0; i < detailRows.length; i++) {
        if (detailRows[i].getAttribute('data-parent') === target) {
            matchingRows.push(detailRows[i]);
        }
    }
    if (!matchingRows.length) return;

    var open = matchingRows[0].hidden;
    for (var j = 0; j < matchingRows.length; j++) {
        matchingRows[j].hidden = !open;
    }

    var financeRows = document.querySelectorAll('.finance-table tr[data-variant-toggle-row]');
    for (var k = 0; k < financeRows.length; k++) {
        if (financeRows[k].getAttribute('data-target') === target) {
            financeRows[k].setAttribute('aria-expanded', open ? 'true' : 'false');
        }
    }

    var buttons = document.querySelectorAll('.finance-table .variant-toggle-icon');
    for (var m = 0; m < buttons.length; m++) {
        if (buttons[m].getAttribute('data-target') === target) {
            buttons[m].setAttribute('aria-expanded', open ? 'true' : 'false');
            buttons[m].setAttribute('title', open ? 'Eigenschaften ausblenden' : 'Eigenschaften anzeigen');
            buttons[m].setAttribute('aria-label', open ? 'Eigenschaften ausblenden' : 'Eigenschaften anzeigen');
        }
    }
}

// Alle Detailzeilen beim initialen Seitenaufbau geschlossen halten.
(function () {
    var detailRows = document.querySelectorAll('.finance-table tr.variant-detail-row');
    for (var i = 0; i < detailRows.length; i++) {
        detailRows[i].hidden = true;
    }
})();
</script>
<?php require __DIR__.'/_layout_end.php'; ?>
