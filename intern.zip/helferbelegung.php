<?php
define('APP_ENTRY_POINT', true);
require __DIR__ . '/app/Modules/Helferverwaltung/Pages/occupancy.php';
