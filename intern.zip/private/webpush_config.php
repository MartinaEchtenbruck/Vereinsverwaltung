<?php
declare(strict_types=1);

/**
 * Web-Push-Konfiguration
 *
 * Speicherort:
 * httpdocs/intern/private/webpush_config.php
 *
 * Diese Datei darf nicht direkt über HTTP erreichbar sein.
 */

return [
    // VAPID-Schlüssel: exakt aus der Schlüsselerzeugung übernehmen.
    'vapid' => [
        'subject' => 'mailto:foerderverein@evkigarumeln.de',
        'public_key' => 'BHLMMQUrGrojbvcxIBjEiR3vhsBjRIM6sQag7vXiCN8KpAkSRFi3BOlvPvjpT-NwRtcmTJogzne61f7byx-MAKk
',
        'private_key' => 'LEoAu6zD0FOGLvxuD2I_7Lp05yc7KmM8qLsBbJn2QAo',
    ],
];?>